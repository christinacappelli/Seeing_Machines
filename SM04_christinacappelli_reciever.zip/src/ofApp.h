// ofApp.h
#pragma once

#include "ofMain.h"

#include "ofxGui.h"
#include "ofxSyphon.h"
#include "ofxCv.h"

 //trying to have the animations pop up without the camera image


class ofApp : public ofBaseApp
{
public:
  void setup();
  void draw();

  void serverListChanged(ofxSyphonServerDirectoryEventArgs& args);
  void serverIndexChanged(int& val);

  ofImage emoji;

  ofxSyphonServerDirectory serverDirectory;
 
  ofxSyphonClient client;

  ofParameter<int> serverIdx;

  ofxPanel guiPanel;
};
