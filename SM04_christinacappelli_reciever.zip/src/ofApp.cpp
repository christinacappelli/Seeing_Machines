// ofApp.cpp
#include "ofApp.h"

// how do i get rid of the camera so just the image pops up in the same place as the sender

void ofApp::setup()
{
  ofSetWindowShape(640, 480);

  // Set up Syphon server directory.
  serverDirectory.setup();
  ofAddListener(serverDirectory.events.serverAnnounced, this, &ofApp::serverListChanged);
  ofAddListener(serverDirectory.events.serverRetired, this, &ofApp::serverListChanged);

  // Set up Syphon client.
  client.setup();

  // Set parameters and GUI.
  serverIdx.set("Server Idx", 0, 0, 10);
  serverIdx.addListener(this, &ofApp::serverIndexChanged);

  guiPanel.setup("Syphon Recv", "settings.json");
  guiPanel.add(serverIdx);

  // Force call events once so that the app starts in a fully configured state.
  ofxSyphonServerDirectoryEventArgs args;
  serverListChanged(args);

  int idx = serverIdx;
  serverIndexChanged(idx);
}

void ofApp::draw()
{
  if (serverDirectory.isValidIndex(serverIdx)) // if index exists
  {
    client.draw(0, 0); // draw the texture at this server
  }

  //guiPanel.draw();
}

void ofApp::serverListChanged(ofxSyphonServerDirectoryEventArgs& args)
{
  // Adjust the range of the server index parameter.
  serverIdx.setMax(serverDirectory.size() - 1);

  // Make sure the server index is within bounds.
  if (serverIdx >= serverDirectory.size())
  {
    serverIdx = 0;
  }
}

void ofApp::serverIndexChanged(int& val)
{
  // Check that the server index is within bounds.
  if (serverDirectory.isValidIndex(serverIdx))
  {
    ofLogNotice(__FUNCTION__) << "Bind server " << serverIdx;

    ofxSyphonServerDescription desc = serverDirectory.getDescription(serverIdx);

    // Bind the client to the selected server.
    client.set(desc);

    // Update the window title.
    ofSetWindowTitle(desc.appName + "::" + desc.serverName);
  }
  else
  {
    ofLogWarning(__FUNCTION__) << "Server " << serverIdx << " out of bounds!";
  }
}
