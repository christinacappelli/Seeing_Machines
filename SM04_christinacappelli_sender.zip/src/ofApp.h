// ofApp.h
#pragma once

#include "ofMain.h"

#include "ofxGui.h"
#include "ofxCv.h"

#include "ofxSyphon.h"


class ofApp : public ofBaseApp
{
public:
    void setup();
    void update();
    void draw();
    void mousePressed(int x, int y, int button);
  
    ofVideoGrabber grabber; // video
    ofImage resultImg; // result image
    ofImage emoji; // cartoon image
    ofColor colorUnderMouse;
   
    ofxCv::ContourFinder contourFinder; // find contour
    
    //
    ofFbo layerFbo; // fbo layer
    ofPixels fboPixels; // fbo pixels

    
    //parametets
    ofParameter<ofColor> colorTarget; // color target
    ofParameter<int> colorOffset;
    ofParameter<int> persistence;
    ofParameter<float> maxDistance;
    ofParameter<float> minArea;
    ofParameter<float> maxArea;
    ofParameter<bool> sendGrabber; // on/off grabber
    ofParameter<bool> sendResult; // on/offresult image
    
    // send over to syphon
    ofxSyphonServer serverGrabber;
    ofxSyphonServer serverSendResult;
    ofxSyphonServer serverPersistence;
    ofxSyphonServer serverMaxDistance;
    ofxSyphonServer serverColorTarget;
    ofxSyphonServer serverColorOffset;
 
    ofxPanel guiPanel;
};
