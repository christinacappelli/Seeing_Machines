//ofApp.cpp
#include "ofApp.h"

// track for color
// when you see color = image pop up

void ofApp::setup()
{
    ofSetWindowShape(640, 480); // window size
    grabber.setup(640, 480); // Start video grabber
    
    // fbo allocate
    ofFboSettings settings;
    settings.width = 640;
    settings.height = 480;
    layerFbo.allocate(settings);
    
    // Set up Syphon servers.
    serverGrabber.setName("Video Input");
    serverPersistence.setName("Persistence");
    serverMaxDistance.setName("MaxDistance");
    serverColorTarget.setName("Color Target");
    serverColorOffset.setName("Color Offset");
    serverSendResult.setName("Send Result");

    // Set parameters
    contourFinder.setUseTargetColor(true); // contour finder
    
    sendGrabber.set("Send Grabber", true); // video
    sendResult.set("Send Result", true); // result image
    persistence.set("Persistence",10,15,0);
    maxDistance.set("MaxDistance",50,0,640);
    minArea.set("Min Area", 0.01f, 0, 0.5f);
    maxArea.set("Max Area", 0.05f, 0, 0.5f);
    emoji.load("1.png");
    colorTarget.set("Color Target", ofColor(255, 0, 0));
    colorOffset.set("Color Offset", 10, 0, 255);

  // gui panel set up
    guiPanel.setup("Syphon Send", "settings.json");
    guiPanel.add(sendGrabber);
    guiPanel.add(colorTarget);
    guiPanel.add(colorOffset);
    guiPanel.add(persistence);
    guiPanel.add(maxDistance);
    guiPanel.add(minArea);
    guiPanel.add(maxArea);
}

void ofApp::update()
{
  grabber.update();
  
  if (grabber.isFrameNew())
  {
      resultImg.setFromPixels(grabber.getPixels());
     
      // Save the color of the pixel under the mouse.
      colorUnderMouse = resultImg.getColor(ofGetMouseX(), ofGetMouseY());
      
      // Update parameters.
      contourFinder.setTargetColor(colorTarget, ofxCv::TRACK_COLOR_HSV);
      contourFinder.setThreshold(colorOffset);
      contourFinder.getTracker().setPersistence(persistence);
      contourFinder.getTracker().setMaximumDistance(maxDistance);
      contourFinder.setMinAreaNorm(minArea);
      contourFinder.setMaxAreaNorm(maxArea);

      // Find contours.
      contourFinder.findContours(resultImg);
      
    
    if (sendGrabber)
    {
      // Send grabber texture.
      // This has to be a pointer, so we add & before the argument.
      serverGrabber.publishTexture(&grabber.getTexture());
    }
  }
}

void ofApp::draw()
{
  //resultImg.draw(0, 0); // draw result
  
  if (sendResult)
  {
    ofSetColor(255);
    ofSetRectMode(OF_RECTMODE_CORNER);

    // Draw the grabber image.
    grabber.draw(0, 0, ofGetWidth(), ofGetHeight());
    
    contourFinder.draw();
      
    // Draw the color under the mouse.
    ofPushStyle();
    ofSetColor(colorUnderMouse);
    ofDrawRectangle(ofGetMouseX() - 25, ofGetMouseY() - 25, 50, 50);
    ofNoFill();
    ofSetColor(colorUnderMouse.getInverted());
    ofDrawRectangle(ofGetMouseX() - 25, ofGetMouseY() - 25, 50, 50);
    ofPopStyle();
    
    //layerFbo.begin();
    for(int i=0; i < contourFinder.size(); i++)
    {
        ofPoint center = ofxCv::toOf(contourFinder.getCenter(i));
        ofRectangle rect = ofxCv::toOf(contourFinder.getBoundingRect(i));
        ofSetRectMode(OF_RECTMODE_CENTER);
        emoji.draw(center.x,center.y,rect.width,rect.height);
    }
    //layerFbo.end();
    
    // Download the FBO data as pixels.
    //layerFbo.readToPixels(fboPixels);
    //layerFbo.draw(0, 0);
      
    serverSendResult.publishScreen(); // Send current screen
   }
    guiPanel.draw(); // draw gui
    
}

void ofApp::mousePressed(int x, int y, int button)
{
  if (!guiPanel.getShape().inside(x, y))
  {
    // Track the color under the mouse.
    colorTarget = colorUnderMouse;
  }
    
}
